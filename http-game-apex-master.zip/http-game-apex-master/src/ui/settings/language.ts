export const language = {
  general: 'General',
  items: 'Items',
  research: 'Research'
};
