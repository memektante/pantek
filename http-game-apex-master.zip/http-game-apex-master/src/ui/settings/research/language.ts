export const language = {
  research: 'Research Settings',
  researchRecoil: 'Recoil Compensation',
  researchRecoilEnable: 'Enable',
  researchRecoilPercentage: 'Recoil Compensation (%)',
  researchWarning: 'These features may be unstable and cause detection. Proceed with caution.'
};
