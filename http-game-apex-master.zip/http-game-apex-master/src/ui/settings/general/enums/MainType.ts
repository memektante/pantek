export enum MainType {
  Map = 'map',
  Radar = 'radar'
}
