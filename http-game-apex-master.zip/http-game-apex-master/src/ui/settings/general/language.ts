export const language = {
  general: 'General Settings',
  generalMap: 'Map',
  generalMapItems: 'Show Items',
  generalMapPlayers: 'Show Players',
  generalRadar: 'Radar',
  generalRadarItems: 'Show Items',
  generalRadarPlayers: 'Show Players',
  generalSense: 'Sense',
  generalSenseItems: 'Highlight Items',
  generalSensePlayers: 'Highlight Players',
  generalViewType: 'Main',
  generalViewTypeMap: 'Show Map',
  generalViewTypeRadar: 'Show Radar'
};
