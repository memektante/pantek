export const language = {
  items: 'Item Settings',
  itemsAmmo: 'Ammo',
  itemsGearBackpack: 'Gear / Backpack',
  itemsGearBodyShield: 'Gear / Body Shield',
  itemsGearEvoShield: 'Gear / Evo Shield',
  itemsGearHelmet: 'Gear / Helmet',
  itemsGearKnockdownShield: 'Gear / Knockdown Shield',
  itemsGrenade: 'Grenades',
  itemsRegen: 'Regen',
  itemsWeaponsEnergy: 'Weapons / Energy',
  itemsWeaponsHeavy: 'Weapons / Heavy',
  itemsWeaponsLight: 'Weapons / Light',
  itemsWeaponShotgun: 'Weapons / Shotguns',
  itemsWeaponsSniper: 'Weapons / Snipers',
  itemsWeaponsSpecial: 'Weapons / Special',
  itemsWeaponAttachments: 'Weapon Attachments'
};
