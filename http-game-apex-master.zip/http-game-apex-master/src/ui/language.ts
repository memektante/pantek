export const language = {
  error: 'An error occurred. Check your console.',
  errorDriver: 'Load this connector in your http-driver.',
  errorProcess: 'Game not found. Did you run it?',
  errorVersion: 'Your http-driver is outdated.',
  reconnect: 'Reconnect'
};
