export enum PacketType {
  BasicAlive,
  BasicSync,
  EntityChange,
  EntityCreate,
  EntityDelete,
  EntityUpdate
}
