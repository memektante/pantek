export abstract class Adapter<T> {
  constructor(
    readonly source: T) {}
}
