export type Grenade = {
  itemId: number;
  itemType: 'Grenade';
  name: string;
};
