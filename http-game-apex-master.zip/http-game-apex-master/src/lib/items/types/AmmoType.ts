export type AmmoType =
  'Energy' |
  'Heavy' |
  'Light' |
  'Shotgun' |
  'Sniper' |
  'Special';
