export type WeaponType =
  'AR' |
  'LMG' |
  'Marksman' |
  'Pistol' |
  'SMG' |
  'Sniper' |
  'Shotgun';
