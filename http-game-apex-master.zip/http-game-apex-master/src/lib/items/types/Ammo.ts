import * as app from '..';

export type Ammo = {
  itemId: number;
  itemType: 'Ammo';
  name: string;
  ammoType: app.AmmoType;
};
