export type GearType =
  'Backpack' |
  'BodyShield' |
  'EvoShield' |
  'Helmet' |
  'KnockdownShield';
