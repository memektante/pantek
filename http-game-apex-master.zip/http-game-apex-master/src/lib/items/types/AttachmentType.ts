export type AttachmentType =
  'BarrelStabilizer' |
  'ExtendedEnergyMag' |
  'ExtendedHeavyMag' |
  'ExtendedLightMag' |
  'ExtendedSniperMag' |
  'LaserLight' |
  'Optics' |
  'ShotgunBolt' |
  'StandardStock' |
  'SniperStock' |
  'BoostedLoader' |
  'DoubleTapTrigger' |
  'HammerpointRounds' |
  'KineticFeeder' |
  'SkullpiercerRifling' |
  'Turbocharger';
