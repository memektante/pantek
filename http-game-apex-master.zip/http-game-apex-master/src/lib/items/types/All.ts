import * as app from '..';

export type All =
  app.Ammo |
  app.Attachment |
  app.Gear |
  app.Grenade |
  app.Regen |
  app.Weapon;
