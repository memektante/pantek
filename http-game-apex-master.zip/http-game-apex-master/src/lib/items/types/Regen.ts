export type Regen = {
  itemId: number;
  itemType: 'Regen';
  name: string;
};
